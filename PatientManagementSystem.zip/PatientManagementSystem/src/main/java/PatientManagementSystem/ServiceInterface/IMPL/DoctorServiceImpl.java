package PatientManagementSystem.ServiceInterface.IMPL;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import PatientManagementSystem.DTOEntity.DoctorDetailsDto;
import PatientManagementSystem.DTOEntity.PatientDetailsDto;
import PatientManagementSystem.Entity.DoctorDetails;
import PatientManagementSystem.JPA.DoctorRepository;
import PatientManagementSystem.MapperClass.DoctorMapper;
import PatientManagementSystem.MapperClass.PatientMapper;
import PatientManagementSystem.ServiceInterface.DoctorServiceInterface;

@Service
public class DoctorServiceImpl implements DoctorServiceInterface{

	@Autowired
	private DoctorRepository doctorRepo;
	
	
	public DoctorServiceImpl(DoctorRepository doctorRepo) {
		super();
		this.doctorRepo = doctorRepo;
	}
	@Override
	public DoctorDetailsDto createDoctorDetails(@RequestBody DoctorDetailsDto doctorDetailsDto) {
		 
		// Convert DTO to entity
		DoctorDetails doctorsdetails=DoctorMapper.toEntity(doctorDetailsDto);
        // Save entity and return converted DTO
        return DoctorMapper.toDTO(doctorRepo.save(doctorsdetails));
	}
	@Override
	public List<DoctorDetailsDto> getAllDoctor() {
        // Get all doctor entities from the repository
		List<DoctorDetails> doctordetails=doctorRepo.findAll();
        // Convert entities to DTOs
		List<DoctorDetailsDto> doctorDtos=new ArrayList<>();

		for(DoctorDetails doctorEntity: doctordetails)	{
			DoctorDetailsDto doctorDto=DoctorMapper.toDTO(doctorEntity);
			doctorDtos.add(doctorDto);
		}
			return doctorDtos;
	}

	
}
