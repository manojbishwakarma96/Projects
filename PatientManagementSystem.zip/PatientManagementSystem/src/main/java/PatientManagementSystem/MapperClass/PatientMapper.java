package PatientManagementSystem.MapperClass;

import PatientManagementSystem.DTOEntity.PatientDetailsDto;
import PatientManagementSystem.Entity.PatientDetails;

public class PatientMapper {

    public static PatientDetailsDto toDTO(PatientDetails entity) {
    	PatientDetailsDto dto = new PatientDetailsDto();
        dto.setPatientId(entity.getPatientId());
        dto.setFirstName(entity.getFirstName());
        dto.setLastName(entity.getLastName());
        dto.setDateOfBirth(entity.getDateOfBirth());
        dto.setGender(entity.getGender());
        dto.setEmail(entity.getEmail());
        dto.setPhoneNumber(entity.getPhoneNumber());
        dto.setAddress(entity.getAddress());
        return dto;
    }

    public static PatientDetails toEntity(PatientDetailsDto dto) {
        PatientDetails entity = new PatientDetails();
        entity.setPatientId(dto.getPatientId());
        entity.setFirstName(dto.getFirstName());
        entity.setLastName(dto.getLastName());
        entity.setDateOfBirth(dto.getDateOfBirth());
        entity.setGender(dto.getGender());
        entity.setEmail(dto.getEmail());
        entity.setPhoneNumber(dto.getPhoneNumber());
        entity.setAddress(dto.getAddress());
        return entity;
    }
}
