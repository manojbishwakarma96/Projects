package PatientManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
