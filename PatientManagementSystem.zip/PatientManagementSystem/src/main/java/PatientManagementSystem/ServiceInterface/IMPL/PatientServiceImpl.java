package PatientManagementSystem.ServiceInterface.IMPL;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import PatientManagementSystem.DTOEntity.PatientDetailsDto;
import PatientManagementSystem.Entity.PatientDetails;
import PatientManagementSystem.JPA.PatientRepository;
import PatientManagementSystem.MapperClass.PatientMapper;
import PatientManagementSystem.ServiceInterface.PatientServices;

@Service
public class PatientServiceImpl implements PatientServices {

    @Autowired
    private PatientRepository patientRepo;

    @Override
    public List<PatientDetailsDto> getAllPatients() {
        // Get all patient entities from the repository
        List<PatientDetails> patientEntities = patientRepo.findAll();

        // Convert entities to DTOs
        List<PatientDetailsDto> patientDtos = new ArrayList<>();
        for (PatientDetails patientEntity : patientEntities) {
            PatientDetailsDto patientDto = PatientMapper.toDTO(patientEntity);
            patientDtos.add(patientDto);
        }

        return patientDtos;
    }


    @Override
    public PatientDetailsDto addPatients(PatientDetailsDto patientDetailsDto) {
        // Convert DTO to entity
        PatientDetails patientDetails = PatientMapper.toEntity(patientDetailsDto);
        // Save entity and return converted DTO
        return PatientMapper.toDTO(patientRepo.save(patientDetails));
    }

    @Override
    public Optional<PatientDetailsDto> getPatientById(Long id) {
        if (id != null) {
            Optional<PatientDetails> optionalPatient = patientRepo.findById(id);
            return optionalPatient.map(patient -> PatientMapper.toDTO(patient));
        } else {
            return Optional.empty();
        }
    }


    @Override
    public PatientDetailsDto updatePatient(PatientDetailsDto patientDetailsDto, Long id) {
        Optional<PatientDetails> optionalPatient = patientRepo.findById(id);
        if (optionalPatient.isPresent()) {
            PatientDetails existingPatient = optionalPatient.get();
            // Update existing patient details with the new details
            existingPatient.setFirstName(patientDetailsDto.getFirstName());
            existingPatient.setLastName(patientDetailsDto.getLastName());
            existingPatient.setDateOfBirth(patientDetailsDto.getDateOfBirth());
            existingPatient.setEmail(patientDetailsDto.getEmail());
            existingPatient.setGender(patientDetailsDto.getGender());
            existingPatient.setAddress(patientDetailsDto.getAddress());
            System.out.println("Existing Patients : " + existingPatient.toString());
            // Save updated entity and return converted DTO
            return PatientMapper.toDTO(patientRepo.save(existingPatient));
        } else {
            // Patient with the given ID not found
            return null;
        }
    }
}
