package PatientManagementSystem.JPA;

import org.springframework.data.jpa.repository.JpaRepository;

import PatientManagementSystem.DTOEntity.PatientDetailsDto;
import PatientManagementSystem.Entity.PatientDetails;

public interface PatientRepository extends JpaRepository<PatientDetails, Long> {

}
