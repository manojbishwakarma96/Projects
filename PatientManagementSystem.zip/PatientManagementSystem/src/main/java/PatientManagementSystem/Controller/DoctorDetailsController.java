package PatientManagementSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import PatientManagementSystem.DTOEntity.DoctorDetailsDto;
import PatientManagementSystem.ServiceInterface.DoctorServiceInterface;

@RestController
@RequestMapping("/doctorDetails")
public class DoctorDetailsController {
	@Autowired
	public DoctorServiceInterface doctorService;

	public DoctorDetailsController(DoctorServiceInterface doctorService) {
		super();
		this.doctorService = doctorService;
	}

	@PostMapping("/addDoctor")
	public DoctorDetailsDto createDoctorDetails(@RequestBody DoctorDetailsDto doctorDetails) {
				return doctorService.createDoctorDetails(doctorDetails);
	}
	@GetMapping("/getAllDoctor")
	public List<DoctorDetailsDto> getAllDoctor() {
		return doctorService.getAllDoctor();
	}
}
