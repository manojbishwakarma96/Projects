package PatientManagementSystem.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import PatientManagementSystem.DTOEntity.PatientDetailsDto;
import PatientManagementSystem.ServiceInterface.PatientServices;

@RestController
@RequestMapping("/patients")
public class PatientController {
	@Autowired
    private final PatientServices patientService;
	
    public PatientController(PatientServices patientService) {
        this.patientService = patientService;
    }

    @GetMapping("/getAll")
    public List<PatientDetailsDto> getAllPatients() {
        return patientService.getAllPatients();
    }

    @GetMapping("/{id}")
    public Optional<PatientDetailsDto> getPatientById(@PathVariable Long id) {
        return patientService.getPatientById(id);
    }

    @PostMapping("/add")
    public PatientDetailsDto addPatient(@RequestBody PatientDetailsDto patientDetails) {
        return patientService.addPatients(patientDetails);
    }

    @PutMapping("/{id}")
    public PatientDetailsDto updatePatient(@RequestBody PatientDetailsDto patientDetails, @PathVariable Long id) {
        return patientService.updatePatient(patientDetails, id);
    }
    
}
