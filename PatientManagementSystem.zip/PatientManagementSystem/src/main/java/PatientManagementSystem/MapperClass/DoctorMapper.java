package PatientManagementSystem.MapperClass;

import PatientManagementSystem.DTOEntity.DoctorDetailsDto;
import PatientManagementSystem.Entity.DoctorDetails;

public class DoctorMapper {

    public static DoctorDetailsDto toDTO(DoctorDetails doctorEntity) {
    	DoctorDetailsDto doctorDto = new DoctorDetailsDto();
    	doctorDto.setDoctorId(doctorEntity.getDoctorId());
    	doctorDto.setFirstName(doctorEntity.getFirstName());
    	doctorDto.setLastName(doctorEntity.getLastname());
    	doctorDto.setDateOfBirth(doctorEntity.getDateofbirth());
    	doctorDto.setAddress(doctorEntity.getAddress());
    	doctorDto.setDepartment(doctorEntity.getDepartment());
    	doctorDto.setServiceType(doctorEntity.getServiceType());
    	doctorDto.setAvailableFrom(doctorEntity.getAvailabeFrom());
    	doctorDto.setYearOfExperience(doctorEntity.getYearOfExperience());
    	doctorDto.setQualification(doctorEntity.getQualification());
    	doctorDto.setSpecialities(doctorEntity.getSpecialities());
    	doctorDto.setIsAvailable(doctorEntity.getIsAvailable());
        return doctorDto;
    }

    public static DoctorDetails toEntity(DoctorDetailsDto dto) {
        DoctorDetails doctorEntity = new DoctorDetails();
        doctorEntity.setDoctorId(dto.getDoctorId());
        doctorEntity.setFirstName(dto.getFirstName());
        doctorEntity.setLastname(dto.getLastName());
        doctorEntity.setDateofbirth(dto.getDateOfBirth());
        doctorEntity.setAddress(dto.getAddress());
        doctorEntity.setDepartment(dto.getDepartment());
        doctorEntity.setServiceType(dto.getServiceType());
        doctorEntity.setAvailabeFrom(dto.getAvailableFrom());
        doctorEntity.setYearOfExperience(dto.getYearOfExperience());
        doctorEntity.setQualification(dto.getQualification());
        doctorEntity.setSpecialities(dto.getSpecialities());
        doctorEntity.setIsAvailable(dto.getIsAvailable());
        return doctorEntity;
    }
}
