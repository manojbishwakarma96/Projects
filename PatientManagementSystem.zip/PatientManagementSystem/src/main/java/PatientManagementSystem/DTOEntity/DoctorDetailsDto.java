package PatientManagementSystem.DTOEntity;

import java.sql.Date;
import java.time.LocalDate;

public class DoctorDetailsDto {
    private long doctorId;
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private String address;
    private String department;
    private String serviceType;
    private LocalDate availableFrom;
    private String yearOfExperience;
    private String qualification;
    private String specialities;
    private String isAvailable;
    
	public DoctorDetailsDto() {
		super();
	}

	public DoctorDetailsDto(long doctorId, String firstName, String lastName, LocalDate dateOfBirth, String address,
			String department, String serviceType, LocalDate availableFrom, String yearOfExperience, String qualification,
			String specialities, String isAvailable) {
		super();
		this.doctorId = doctorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.department = department;
		this.serviceType = serviceType;
		this.availableFrom = availableFrom;
		this.yearOfExperience = yearOfExperience;
		this.qualification = qualification;
		this.specialities = specialities;
		this.isAvailable = isAvailable;
	}

	public long getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public LocalDate getAvailableFrom() {
		return availableFrom;
	}

	public void setAvailableFrom(LocalDate availableFrom) {
		this.availableFrom = availableFrom;
	}

	public String getYearOfExperience() {
		return yearOfExperience;
	}

	public void setYearOfExperience(String yearOfExperience) {
		this.yearOfExperience = yearOfExperience;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getSpecialities() {
		return specialities;
	}

	public void setSpecialities(String specialities) {
		this.specialities = specialities;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
   
    
}
