package PatientManagementSystem.ServiceInterface;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import PatientManagementSystem.DTOEntity.DoctorDetailsDto;

public interface DoctorServiceInterface {

	public DoctorDetailsDto createDoctorDetails(@RequestBody DoctorDetailsDto doctorDetails);

	public List<DoctorDetailsDto> getAllDoctor();
}
