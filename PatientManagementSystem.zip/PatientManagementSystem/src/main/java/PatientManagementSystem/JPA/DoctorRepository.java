package PatientManagementSystem.JPA;

import org.springframework.data.jpa.repository.JpaRepository;

import PatientManagementSystem.Entity.DoctorDetails;

public interface DoctorRepository extends JpaRepository<DoctorDetails, Long>{

}
