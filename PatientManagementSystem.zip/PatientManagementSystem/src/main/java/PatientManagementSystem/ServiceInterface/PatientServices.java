package PatientManagementSystem.ServiceInterface;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.RequestBody;

import PatientManagementSystem.DTOEntity.PatientDetailsDto;
import PatientManagementSystem.Entity.PatientDetails;
public interface PatientServices {
	List<PatientDetailsDto> getAllPatients();
	PatientDetailsDto addPatients(@RequestBody PatientDetailsDto patients) ;
	Optional<PatientDetailsDto> getPatientById(Long id);
	PatientDetailsDto updatePatient(@RequestBody PatientDetailsDto patientDetails, Long id);
}
