package PatientManagementSystem.Entity;

import java.sql.Date;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="doctor_details")
public class DoctorDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long doctorId;
	@Column(name = "first_name", nullable = false)
	private String firstName;
	
    @Column(name = "last_name",nullable = false)
	private String lastname;
    
    @Column(name = "date_of_birth",nullable = false)
    private LocalDate dateofbirth;
    
    @Column(name = "address",nullable = false)
	private String address;
    
    @Column(name = "department",nullable = false)
	private String department;
    
    @Column(name = "serviceType",nullable = false)
	private String serviceType;
    
    @Column(name = "availabeFrom",nullable = false)
    private LocalDate availabeFrom;
    
    @Column(name = "experience",nullable = false)
  	private String yearOfExperience;
    
    @Column(name = "qualification",nullable = false)
  	private String qualification;
    
    @Column(name = "specialities",nullable = false)
   	private String specialities;
    
    @Column(name = "isAvailable",nullable = false)
	private String isAvailable;
	   	
	public DoctorDetails() {
		super();
	}

	public DoctorDetails(long doctorId, String firstName, String lastname, LocalDate dateofbirth, String address,
			String department, String serviceType, LocalDate availabeFrom, String yearOfExperience, String qualification,
			String specialities, String isAvailable) {
		super();
		this.doctorId = doctorId;
		this.firstName = firstName;
		this.lastname = lastname;
		this.dateofbirth = dateofbirth;
		this.address = address;
		this.department = department;
		this.serviceType = serviceType;
		this.availabeFrom = availabeFrom;
		this.yearOfExperience = yearOfExperience;
		this.qualification = qualification;
		this.specialities = specialities;
		this.isAvailable = isAvailable;
	}



	public long getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public LocalDate getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(LocalDate dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public LocalDate getAvailabeFrom() {
		return availabeFrom;
	}

	public void setAvailabeFrom(LocalDate availabeFrom) {
		this.availabeFrom = availabeFrom;
	}

	public String getYearOfExperience() {
		return yearOfExperience;
	}

	public void setYearOfExperience(String yearOfExperience) {
		this.yearOfExperience = yearOfExperience;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getSpecialities() {
		return specialities;
	}

	public void setSpecialities(String specialities) {
		this.specialities = specialities;
	}

	@Override
	public String toString() {
		return "DoctorDetails [doctorId=" + doctorId + ", firstName=" + firstName + ", lastname=" + lastname
				+ ", dateofbirth=" + dateofbirth + ", address=" + address + ", department=" + department
				+ ", serviceType=" + serviceType + ", availabeFrom=" + availabeFrom + ", yearOfExperience="
				+ yearOfExperience + ", qualification=" + qualification + ", specialities=" + specialities
				+ ", available=" + isAvailable + "]";
	}
}